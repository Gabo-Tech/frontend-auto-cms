# frontend-auto-cms

Turn any frontend app into a mini-CMS with one import and a dedicated editor route.

## Install

```bash
npm install frontend-auto-cms
```

Postinstall runs a setup wizard that:

- asks for a passcode,
- scans project files (`.html`, `.jsx`, `.tsx`, `.vue`, `.astro`, `.svelte`),
- generates `cms-content.json`, `.cms-config.json`, and `public/cms-runtime-auth.json`.
- optionally configures GitHub/GitLab publishing in `.cms-hosting.json` + `public/cms-hosting.json`.
- asks for a custom dashboard route and auto-detects editable pages into `public/cms-settings.json`.
- token is entered manually in dashboard at publish time (not stored in config).

## Use in app

```ts
import "frontend-auto-cms";
```

Or:

```html
<script type="module" src="/node_modules/frontend-auto-cms/dist/runtime/dashboard.js"></script>
```

Run your app and open your configured dashboard route (default: `/dashboard`).

The dashboard has:
- page tabs (About, Contact, Privacy, Terms, etc.),
- live preview iframe,
- one unified ordered editor list for non-technical users.

## Commands

- `npx frontend-auto-cms setup` - rerun scanner and regenerate content baseline.
- `npx frontend-auto-cms apply` - apply `cms-export.patch.json` generated from dashboard.
- `npx frontend-auto-cms doctor` - quick installation check.

## i18n Local AI

Install optional peer:

```bash
npm install @xenova/transformers
```

In the CMS i18n tab, click **Auto-translate all languages** to generate locale dictionaries in memory, then export patch and apply.

## Persistence

- Live edits apply immediately to DOM.
- Content and locales are cached in `localStorage`.
- Save + Publish pushes changes to configured hosting provider or downloads `cms-export.patch.json` as fallback.
- CLI apply writes source replacements and locale JSON files.

## Security note

Browser runtime passcode gate is intentionally lightweight for local editing workflows. Provider token is entered manually for each publish and is not stored, but is still handled in browser memory during that action. Prefer short-lived tokens with restricted repo scope or move publishing behind a secure backend proxy.
